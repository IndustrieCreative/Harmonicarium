 /**
 * This file is part of HARMONICARIUM, a web app which allows users to play
 * the Harmonic Series dynamically by changing its fundamental tone in real-time.
 * It is available in its latest version from:
 * https://github.com/IndustrieCreative/Harmonicarium
 * 
 * @license
 * Copyright (C) 2017-2020 by Walter Mantovani (http://armonici.it).
 * Written by Walter Mantovani.
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/* globals HARMONICARIUM */

"use strict";

/*==============================================================================*
 * WEB-MIDI-LINK MESSAGES HANDLER 
 * https://www.g200kg.com/en/docs/webmidilink/index.html
 * (implementation: experimental - work in progress)
 *==============================================================================*/
HARMONICARIUM.midi.WebMidiLinkIn = function() {

    class WebMidiLinkIn {
        constructor(dhc, midi) {
            this.dhc = dhc;
            this.midi = midi;
            if (window.opener) {
                this.hostWindow = window.opener;
            }
            else{
                this.hostWindow = window.parent;
            }

            window.addEventListener("message", (e) => this.receiveMessage(e) );
        }
        // @old icWebMidiLinkInput
        receiveMessage(e) {
           if (typeof e.data === 'string') {
                var msg = e.data.split(",");
                switch (msg[0]) {
                    // Level 1 messages
                    case "link":
                        // Try to determinate which window sent the message
                        let synthNum = 0;
                        for (const [key, webMidiOut] of Object.entries(this.midi.port.webMidi.outputs)) {
                            if (e.source === webMidiOut.synthWindow) {
                                synthNum = key;
                            } 
                        }
                        // https://www.g200kg.com/en/docs/webmidilink/spec.html @ Link Level 1
                        switch (msg[1]) {
                            // -------------------------------------------------
                            // Host<=Synth : if Harmonicarium is used as HOST
                            case "ready":
                                this.midi.port.webMidi.outputs[synthNum].becomeReady(msg[1]);
                                break;
                            case "progress":
                                this.midi.port.webMidi.outputs[synthNum].becomeReady(msg[1]);
                                break;
                            case "patch":
                                console.log("WebMidiLink Level 1 message (link) 'patch' is not implemented yet!");
                                // ReceivePatchStringFromSynth(msg[2]);
                                break;
                            // -------------------------------------------------
                            // Host=>Synth : if Harmonicarium is used as INSTRUMENT/SYNTH
                            case "reqpatch":
                                console.log("WebMidiLink Level 1 message (link) 'reqpatch' is not implemented yet!");
                                // e.source.postMessage("link,patch," + ReqPatchString(),"*");
                                break;
                            case "setpatch":
                                console.log("WebMidiLink Level 1 message (link) 'setpatch' is not implemented yet!");
                                // ReceivePatchStringFromHost(msg[2]);
                                break;
                            // -------------------------------------------------
                            default:
                                console.error("Unknown WebMidiLink Level 1 message (link): '"+ msg[1] +"'");
                                break;
                        }
                        break;
                    // Level 0 messages
                    case "midi":
                        // Create a MIDI message
                        let midievent = {
                            data: [parseInt(msg[1], 16), parseInt(msg[2], 16), parseInt(msg[3], 16), false, false],
                            srcElement: {
                                id: "webmidilink_in",
                                manufacturer : "Industrie Creative",
                                name: "WebMidiLink Port",
                                type: "input"
                            }
                        };
                        // Re-send the MIDI generated message
                        this.midi.in.midiMessageReceived(midievent);
                        break;
                }
            }
        }

        // Should be called when Harmonicarium (hosted) is ready and listening
        // Synth=>Host
        // @old icWebMidiLinkReady
        sendReadyMessage() {
            // Send message to the host web app
            this.hostWindow.postMessage("link,ready", "*");
        }
    }

    return WebMidiLinkIn;
}();

HARMONICARIUM.midi.WebMidiLinkOut = function() {

    class WebMidiLinkOut {
        constructor(key, id, dhc, midi) {
            this.dhc = dhc;
            this.midi = midi;
            this.id = id;
            this.manufacturer = "Industrie Creative";
            this.name = `WebMidiLink OUT Port (${key+1})`;
            this.state = "disconnected";
            this.type = "output";

            this.key = key;
            this.uniqKey = `${dhc.id}_${key}`;
            this.synthWindow = {closed: true};
            this.isReady = false;
            this.synthList = 'adhocSynthList'; // or 'g200kgSynthList'

            let portsContainer = document.getElementById(`HTMLf_webMidiLinkPorts${dhc.id}`),
                newPortUI = HARMONICARIUM.tmpl.webMidiLinkPorts(this.uniqKey, this.key+1);
            portsContainer.appendChild(newPortUI);

            this.uiElements = {
                fn: {
                    webMidiLinkPorts: portsContainer,
                    
                    webMidiLinkLoader: document.getElementById(`HTMLf_webMidiLinkLoader${this.uniqKey}`),

                    webMidiLinkUrl: document.getElementById(`HTMLf_webMidiLinkUrl${this.uniqKey}`),
                    webMidiLinkStatus: document.getElementById(`HTMLf_webMidiLinkStatus${this.uniqKey}`),
                    webMidiLinkSynthSelect: document.getElementById(`HTMLf_webMidiLinkSynthSelect${this.uniqKey}`),
                    webMidiLinkSynthLoad: document.getElementById(`HTMLf_webMidiLinkSynthLoad${this.uniqKey}`),
                },
                in: {

                },
                out: {

                },
            };

            this.initUI();

        }
        initUI() {
            // Add event listeners on <select> and <button> elements
            this.uiElements.fn.webMidiLinkSynthSelect.addEventListener("change", (e) => {
                this.uiElements.fn.webMidiLinkUrl.value = e.target[e.target.selectedIndex].value;
            } );
            this.uiElements.fn.webMidiLinkSynthLoad.addEventListener("click", () => {
                this.load(this.uiElements.fn.webMidiLinkUrl.value);
            } );

            let sl = HARMONICARIUM.midi.WebMidiLinkOut[this.synthList];
            this.uiElements.fn.webMidiLinkUrl.value = sl[0].url;
            for (let i = 0; i < sl.length; ++i) {
                let optTxt = `${sl[i].description}: ${sl[i].name} (by ${sl[i].author})`;
                this.uiElements.fn.webMidiLinkSynthSelect.options[i] = new Option(optTxt, sl[i].url);
            }

        }
        openPort() {
            this.uiElements.fn.webMidiLinkLoader.style.display = "table";
            this.startStateCheck();
        }
        closePort() {
            this.unload();
            this.stopStateCheck();
            this.uiElements.fn.webMidiLinkLoader.style.display = "none";
        }
        load(url) {
            alert("A new popup-window containing a web-app instrument is about to be opened and may end up behind the current browser window.\n\nMake sure you interact at least once with the User Interface of the instrument that opened in the new popup-window before you start sending WebMidiLink signals from Harmonicarium.\n\nFor security reasons, the browser may suspend the AudioContext status until the user interacts with that window.\n\nClick OK to continue.");
            this.synthWindow = window.open(url, (this.id +"_window"), "width=900,height=670,scrollbars=yes,resizable=yes");
            this.state = "connected";
            let uiStatus = this.uiElements.fn.webMidiLinkStatus;
            uiStatus.innerText = "LOADED";
            uiStatus.classList.remove("webmidilinkNotLoaded", "webmidilinkProgress");
            uiStatus.classList.add("webmidilinkLoaded");
            this.startStateCheck();
        }
        unload() {
            if (this.synthWindow.window){
                this.synthWindow.close();
            }
            let uiStatus = this.uiElements.fn.webMidiLinkStatus;
            uiStatus.innerText = "NOT LOADED";
            uiStatus.classList.remove("webmidilinkLoaded", "webmidilinkProgress");
            uiStatus.classList.add("webmidilinkNotLoaded");
        }
        send(msg) {
             this.sendMessage(this.synthWindow, "midi," + msg.map(e => e.toString(16)));
        }
        // this.AllSoundOff = function() {
        //     this.SendMessage(this.synthWindow, "midi,b0,78,0");
        // }
        sendMessage(synthWindow, msg) {
            if (this.synthWindow.window) {
                this.synthWindow.postMessage(msg, "*");
            } else {
                // let uiStatus = this.uiElements.fn.webMidiLinkStatus;
                // uiStatus.innerText = "NOT LOADED";
                // uiStatus.classList.remove("webmidilinkLoaded", "webmidilinkProgress");
                // uiStatus.classList.add("webmidilinkNotLoaded");
            }
        }
        startStateCheck() {
            this.stateCheckTimer = setInterval( () => {
                if (this.synthWindow.closed) {
                    clearInterval(this.stateCheckTimer);
                    this.unload();
                }
            }, 1500);
        }
        stopStateCheck() {
            clearInterval(this.stateCheckTimer);
        }
        becomeReady(msg) {
            let uiStatus = this.uiElements.fn.webMidiLinkStatus;
            if (msg === "ready") {
                this.isReady = true;
                uiStatus.innerText = "LOADED (ready)";
                uiStatus.classList.remove("webmidilinkNotLoaded", "webmidilinkProgress");
                uiStatus.classList.add("webmidilinkLoaded");
            } else if (msg === "progress") {
                this.isReady = false;
                uiStatus.innerText = "LOADING IN PROGRESS...";
                uiStatus.classList.remove("webmidilinkNotLoaded", "webmidilinkLoaded");
                uiStatus.classList.add("webmidilinkProgress");
            }
        }
        // @old icWebMidiLinkSetUrl
        // onchange="icWebMidiLinkSetUrl('HTMLf_webMidiLinkUrl0_${id}',this[this.selectedIndex].value)"
        // onchange="icWebMidiLinkSetUrl('HTMLf_webMidiLinkUrl1_${id}',this[this.selectedIndex].value)"
        // static setUrl(id, url) {
        //     var obj = document.getElementById(id);
        //     obj.value = url;
        // }
    }

    return WebMidiLinkOut;

}();
