HARMONNICARIUM.defaults = {
	synth: {	
		status: true,
		volumeMaster: 0.8,
		volumeFT: 0.8,
		volumeHT: 0.8,
		waveformFT: 'triangle',
		waveformHT: 'sine',
	    attack: 0.3,
	    decay: 0.15,
	    sustain: 0.68,
	    release: 0.3,
	    portamento: 0.03,
	    reverb: 0.5
	}
};