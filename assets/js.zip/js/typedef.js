
/*==============================================================================*
 * INTERNAL PRIMITIVES
 *==============================================================================*/

/**
 * Transpose ratio<br>
 *     A positive floating point number.
 *     <em>Examples:</em>
 *     <ul>
 *     <li>2, 4, 8, 16... for octaves up </li>
 *     <li>0.5, 0.25, 0.125, 0.0625... for octaves down </li>
 *     <li>1 to not transpose </li>
 *     </ul>
 *
 * @global
 * @typedef {number} tratio
 */

/**
 * Midicent<br>
 * A midicent is one floating points MIDI-note-number unit.<br>
 *     It can be a positive or negative floating point number.<br>
 *     Considering the description of midicent proposed in the following links, our midicent should be called <em>hecto-midicent</em>.<br>
 * <ul>
 * <li>{@link https://fr.wikipedia.org/wiki/Midicent}</li>
 * <li>{@link http://support.ircam.fr/docs/om/om6-manual/co/Score-Objects-Intro.html#zdN1d7}</li>
 * </ul>
 *
 * @example <caption>How to convert a given frequency in hertz to midicent.</caption>
 * // Variables description:
 * midiA4 = 69;    // The A4 note in MIDI note number notation
 * semitones = 12; // The number of semitones of the 12-EDO
 * hzA4 = 440;     // The A4 note in hertz
 * // Math.log2()     Because we are dividing the octave (frequency ratio 2)
 * 
 * midicent = midiA4 + semitones * Math.log2(frequency / hzA4)
 * //                                        ^^^^^^^^^          
 * //                                        Input freq.
 * 
 * @global
 * @typedef {number} midicent
 */

/**
 * Tone Type<br>
 *     A string composed by two lowercase characters, representing one of the two tone types:
 *     Fundamental Tones (FT `-> 'ft'`) and Harmonic Tones (HT `-> 'ht'`).
 * 
 * @global
 * @typedef {('ft'|'ht')} tonetype
 */

/**
 * MIDI note number<br>
 *     A integer number, officially it must be a 8-bit unsigned integer (between 0 and 127 included).<br>
 *     Negative numbers and number greater than 127 still mean a certain frequency, 
 *     but you cannot send them to MIDI devices.
 * 
 * @global
 * @typedef {number} midinnum
 */

/**
 * Hertz<br>
 *     A positive floating point number, greater than zero.
 * 
 * @global
 * @typedef {number} hertz
 */

/**
 * Xtone number<br>
 *     An integer number, representing a FT or HT relative tone.<br>
 *     If it represents an FT, it is relative to FT0, alias the FM (Fundamental Mother).
 *     If it represents an HT, it is relative to HT1, alias the fundamental of the harmonic/subharmonic series.
 * 
 * @global
 * @typedef {number} xtnum
 */

/**
 * Velocity<br>
 *     8-bit unsigned integer (between 0 and 127 included)
 * 
 * @global
 * @typedef {number} velocity
 */

/**
 * MIDI Channel<br>
 *     4-bit unsigned integer (between 0 and 15 included)
 * 
 * @global
 * @typedef {number} midichan
 */

/*==============================================================================*
 * INTERNAL OBJECTS
 *==============================================================================*/

/**
 * A MIDI message (data + timestamp)
 * 
 * @typedef {Array<{2}>} OtherMidiMsg
 *
 * @property {Uint8Array} 0 - Message; an array of 8-bit unsigned integers
 * @property {number}     1 - Time-stamp; a floating point number
 */

/*==============================================================================*
 * EXTERNAL OBJECTS
 *==============================================================================*/

/**
 * @name HTMLElement
 * @typedef HTMLElement
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement}
 */

/**
 * @name File
 * @typedef File
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/File}
 */

/**
 * @name MIDIMessageEvent
 * @typedef MIDIMessageEvent
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/MIDIMessageEvent}
 */

/**
 * @name AudioContext
 * @typedef AudioContext
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/AudioContext}
 */

/**
 * @name GainNode
 * @typedef GainNode
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/GainNode}
 */

/**
 * @name DynamicsCompressorNode
 * @typedef DynamicsCompressorNode
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/DynamicsCompressorNode}
 */

/**
 * @name ConvolverNode
 * @typedef ConvolverNode
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/ConvolverNode}
 */

/**
 * WARNING: As of the August 29 2014 Web Audio API spec publication,
 *     this feature has been marked as deprecated, and was replaced by AudioWorklet (see {@link https://developer.mozilla.org/en-US/docs/Web/API/AudioWorkletNode|AudioWorkletNode})
 * 
 * @name ScriptProcessorNode
 * @typedef ScriptProcessorNode
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/ScriptProcessorNode}
 */

/**
 * @name MIDIAccess
 * @typedef MIDIAccess
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/MIDIAccess}
 * @see {@link https://www.w3.org/TR/webmidi/#midiaccess-interface}
 */

/**
 * @name MIDIConnectionEvent
 * @typedef MIDIConnectionEvent
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/MIDIConnectionEvent}
 * @see {@link https://www.w3.org/TR/webmidi/#midiconnectionevent-interface}
 */

/**
 * @name MIDIPort
 * @typedef MIDIPort
 * @see {@link https://www.w3.org/TR/webmidi/#midiport-interface}
 */

/**
 * @name ArrayBuffer
 * @typedef ArrayBuffer
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer}
 */

/**
 * @name Uint8Array
 * @typedef Uint8Array
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array}
 */

/**
 * @name DOMException
 * @typedef DOMException
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/DOMException}
 */
